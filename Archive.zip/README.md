# About the project

A currency converter with from 1 currency to another

# Frontend

[Here](./frontend/README.md) the readme about the frontend part.

# Backend

[Here](./backend/README.md) the readme about the frontend part.
