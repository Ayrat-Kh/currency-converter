# How to run and develop

```
pnpm install
pnpm start
```
