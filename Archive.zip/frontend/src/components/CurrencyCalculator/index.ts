export { CurrencyCalculatorContainer as CurrencyCalculator } from './CurrencyCalculatorContainer';
